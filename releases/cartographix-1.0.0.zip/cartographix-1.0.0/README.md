#CartoGraphix

A simple webapp that allows users to create stylised maps. Very much a work in progress!

Created by William Bradshaw.